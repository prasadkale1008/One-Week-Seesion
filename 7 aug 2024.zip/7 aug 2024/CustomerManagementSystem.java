import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CustomerManagementSystem {
    private List<Customer> customers;

    public CustomerManagementSystem() {
        customers = new ArrayList<>();
    }

    public void addCustomer(String customerId, String name, String email) {
        if (findCustomerById(customerId) != null) {
            System.out.println("Customer with ID " + customerId + " already exists.");
        } else {
            Customer newCustomer = new Customer(customerId, name, email);
            customers.add(newCustomer);
            System.out.println("Customer " + name + " added successfully.");
        }
    }

    public void removeCustomer(String customerId) {
        Customer customerToRemove = findCustomerById(customerId);
        if (customerToRemove != null) {
            customers.remove(customerToRemove);
            System.out.println("Customer with ID " + customerId + " removed successfully.");
        } else {
            System.out.println("Customer with ID " + customerId + " does not exist.");
        }
    }

    public String searchCustomer(String customerId) {
        Customer customer = findCustomerById(customerId);
        if (customer != null) {
            return customer.toString();
        } else {
            return "Customer with ID " + customerId + " not found.";
        }
    }

    public void listAllCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            for (Customer customer : customers) {
                System.out.println(customer);
            }
        }
    }

    public void sortCustomersByName() {
        Collections.sort(customers, Comparator.comparing(Customer::getName));
        System.out.println("Customers sorted by name.");
    }

    public void sortCustomersById() {
        Collections.sort(customers, Comparator.comparing(Customer::getCustomerId));
        System.out.println("Customers sorted by ID.");
    }

    private Customer findCustomerById(String customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId().equals(customerId)) {
                return customer;
            }
        }
        return null;
    }
}
