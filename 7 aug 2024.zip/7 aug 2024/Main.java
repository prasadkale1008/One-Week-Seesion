import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CustomerManagementSystem cms = new CustomerManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Customer Management System ---");
            System.out.println("1. Add a Customer");
            System.out.println("2. Remove a Customer");
            System.out.println("3. Search for a Customer");
            System.out.println("4. List All Customers");
            System.out.println("5. Sort Customers by Name");
            System.out.println("6. Sort Customers by ID");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter Customer ID: ");
                    String customerId = scanner.nextLine();
                    System.out.print("Enter Customer Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Customer Email: ");
                    String email = scanner.nextLine();
                    cms.addCustomer(customerId, name, email);
                    break;

                case "2":
                    System.out.print("Enter Customer ID to remove: ");
                    customerId = scanner.nextLine();
                    cms.removeCustomer(customerId);
                    break;

                case "3":
                    System.out.print("Enter Customer ID to search: ");
                    customerId = scanner.nextLine();
                    System.out.println(cms.searchCustomer(customerId));
                    break;

                case "4":
                    cms.listAllCustomers();
                    break;

                case "5":
                    cms.sortCustomersByName();
                    break;

                case "6":
                    cms.sortCustomersById();
                    break;

                case "7":
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }
}

